﻿using System;

class Program
{
    static void Main(string[] args)
    {
        double a = 0, b = 1, n, c, i;
        Console.WriteLine("Enter number for Fibonacci sequence");
        n = double.Parse(Console.ReadLine());
        Console.WriteLine("Fibonacci sequence is:");
        Console.WriteLine("" + a);
        Console.WriteLine("" + b);

        for (i = 1; i <= n; i++)
        {
            c = a + b;
            a = b;
            b = c;
            Console.WriteLine("" + c);

        }
       
    }
}

