﻿using System;

class Program
{
    static void Main(string[] args)
    {
        char c = '\u0048';
        Console.WriteLine(c);
    }
}

