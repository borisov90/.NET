﻿using System;
using System.Collections.Generic;



class Program
{
    static void Main()
    {
        double doubleVar = 34.567839023;
        float floatVar = 12.345f;
        double fVar = 8923.1234857;
        float var2 = 3456.091f;

        Console.WriteLine(doubleVar);
        Console.WriteLine(floatVar);
        Console.WriteLine(fVar);
        Console.WriteLine(var2);
    }
}

