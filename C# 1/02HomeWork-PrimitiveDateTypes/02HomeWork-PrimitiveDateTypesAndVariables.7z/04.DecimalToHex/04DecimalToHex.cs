﻿using System;

class Program
{
    static void Main(string[] args)
    {
        int decValue = 254;
        string hexValue = Convert.ToString(decValue,16);
        Console.WriteLine(hexValue);
    }
}

