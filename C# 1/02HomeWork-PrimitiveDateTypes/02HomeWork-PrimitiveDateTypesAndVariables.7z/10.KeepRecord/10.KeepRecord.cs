﻿using System;


class Program
{
    static void Main(string[] args)
    {
        string fristName = "Pencho";
        string lastName = "Marinkin";
        char gender = 'm';
        byte age = 24;
        int idNUmber = 602030501;
        uint employeeIDnumber = 27560000;

        Console.WriteLine(fristName);
        Console.WriteLine(lastName);
        Console.WriteLine(gender);
        Console.WriteLine(age);
        Console.WriteLine(idNUmber);
        Console.WriteLine(employeeIDnumber);

    }
}
